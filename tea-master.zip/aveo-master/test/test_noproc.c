#include <stdio.h>
#include <ve_offload.h>

int main(int argc, char *argv[])
{
  printf("Testing automatic proc cleanup when no proc was actually created.\n");
}

