/**
 * @file   veo_vhshm_defs.h
 * @brief  Header file for VHSHM
 */

#ifndef _VEO_VHSHM_DEFS_H
#define _VEO_VHSHM_DEFS_H

#define VHSHM_GET 1
#define VHSHM_AT  2
#define VHSHM_DT  3

#endif
